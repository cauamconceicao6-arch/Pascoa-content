function mostrarPix() {
  document.getElementById("pix-area").style.display = "block";
}

function copiarPix() {
  const chave = document.getElementById("chavePix").innerText;
  navigator.clipboard.writeText(chave).then(() => {
    alert("Chave PIX copiada: " + chave);
  }).catch(err => {
    alert("Erro ao copiar chave PIX.");
  });
}
